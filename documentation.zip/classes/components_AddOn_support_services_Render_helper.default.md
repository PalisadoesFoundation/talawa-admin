[talawa-admin](../README.md) / [Modules](../modules.md) / [components/AddOn/support/services/Render.helper](../modules/components_AddOn_support_services_Render_helper.md) / default

# Class: default

[components/AddOn/support/services/Render.helper](../modules/components_AddOn_support_services_Render_helper.md).default

## Table of contents

### Constructors

- [constructor](components_AddOn_support_services_Render_helper.default.md#constructor)

## Constructors

### constructor

• **new default**(): [`default`](components_AddOn_support_services_Render_helper.default.md)

#### Returns

[`default`](components_AddOn_support_services_Render_helper.default.md)
