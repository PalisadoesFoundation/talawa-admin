[talawa-admin](../README.md) / [Modules](../modules.md) / [components/IconComponent/IconComponent](../modules/components_IconComponent_IconComponent.md) / InterfaceIconComponent

# Interface: InterfaceIconComponent

[components/IconComponent/IconComponent](../modules/components_IconComponent_IconComponent.md).InterfaceIconComponent

## Table of contents

### Properties

- [fill](components_IconComponent_IconComponent.InterfaceIconComponent.md#fill)
- [height](components_IconComponent_IconComponent.InterfaceIconComponent.md#height)
- [name](components_IconComponent_IconComponent.InterfaceIconComponent.md#name)
- [width](components_IconComponent_IconComponent.InterfaceIconComponent.md#width)

## Properties

### fill

• `Optional` **fill**: `string`

#### Defined in

[src/components/IconComponent/IconComponent.tsx:17](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/IconComponent/IconComponent.tsx#L17)

___

### height

• `Optional` **height**: `string`

#### Defined in

[src/components/IconComponent/IconComponent.tsx:18](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/IconComponent/IconComponent.tsx#L18)

___

### name

• **name**: `string`

#### Defined in

[src/components/IconComponent/IconComponent.tsx:16](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/IconComponent/IconComponent.tsx#L16)

___

### width

• `Optional` **width**: `string`

#### Defined in

[src/components/IconComponent/IconComponent.tsx:19](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/IconComponent/IconComponent.tsx#L19)
