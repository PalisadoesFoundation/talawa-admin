[talawa-admin](../README.md) / [Modules](../modules.md) / [components/CheckIn/types](../modules/components_CheckIn_types.md) / InterfaceUser

# Interface: InterfaceUser

[components/CheckIn/types](../modules/components_CheckIn_types.md).InterfaceUser

## Table of contents

### Properties

- [\_id](components_CheckIn_types.InterfaceUser.md#_id)
- [firstName](components_CheckIn_types.InterfaceUser.md#firstname)
- [lastName](components_CheckIn_types.InterfaceUser.md#lastname)

## Properties

### \_id

• **\_id**: `string`

#### Defined in

[src/components/CheckIn/types.ts:2](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/CheckIn/types.ts#L2)

___

### firstName

• **firstName**: `string`

#### Defined in

[src/components/CheckIn/types.ts:3](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/CheckIn/types.ts#L3)

___

### lastName

• **lastName**: `string`

#### Defined in

[src/components/CheckIn/types.ts:4](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/CheckIn/types.ts#L4)
