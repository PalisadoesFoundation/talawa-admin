[talawa-admin](../README.md) / [Modules](../modules.md) / [components/CollapsibleDropdown/CollapsibleDropdown](../modules/components_CollapsibleDropdown_CollapsibleDropdown.md) / InterfaceCollapsibleDropdown

# Interface: InterfaceCollapsibleDropdown

[components/CollapsibleDropdown/CollapsibleDropdown](../modules/components_CollapsibleDropdown_CollapsibleDropdown.md).InterfaceCollapsibleDropdown

## Table of contents

### Properties

- [screenName](components_CollapsibleDropdown_CollapsibleDropdown.InterfaceCollapsibleDropdown.md#screenname)
- [target](components_CollapsibleDropdown_CollapsibleDropdown.InterfaceCollapsibleDropdown.md#target)

## Properties

### screenName

• **screenName**: `string`

#### Defined in

[src/components/CollapsibleDropdown/CollapsibleDropdown.tsx:9](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/CollapsibleDropdown/CollapsibleDropdown.tsx#L9)

___

### target

• **target**: `TargetsType`

#### Defined in

[src/components/CollapsibleDropdown/CollapsibleDropdown.tsx:10](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/CollapsibleDropdown/CollapsibleDropdown.tsx#L10)
