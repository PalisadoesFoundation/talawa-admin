[talawa-admin](../README.md) / [Modules](../modules.md) / [components/CheckIn/types](../modules/components_CheckIn_types.md) / InterfaceAttendeeQueryResponse

# Interface: InterfaceAttendeeQueryResponse

[components/CheckIn/types](../modules/components_CheckIn_types.md).InterfaceAttendeeQueryResponse

## Table of contents

### Properties

- [event](components_CheckIn_types.InterfaceAttendeeQueryResponse.md#event)

## Properties

### event

• **event**: `Object`

#### Type declaration

| Name | Type |
| :------ | :------ |
| `_id` | `string` |
| `attendeesCheckInStatus` | [`InterfaceAttendeeCheckIn`](components_CheckIn_types.InterfaceAttendeeCheckIn.md)[] |

#### Defined in

[src/components/CheckIn/types.ts:19](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/CheckIn/types.ts#L19)
