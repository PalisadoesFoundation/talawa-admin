[talawa-admin](../README.md) / [Modules](../modules.md) / [components/OrgProfileFieldSettings/OrgProfileFieldSettings](../modules/components_OrgProfileFieldSettings_OrgProfileFieldSettings.md) / InterfaceCustomFieldData

# Interface: InterfaceCustomFieldData

[components/OrgProfileFieldSettings/OrgProfileFieldSettings](../modules/components_OrgProfileFieldSettings_OrgProfileFieldSettings.md).InterfaceCustomFieldData

## Table of contents

### Properties

- [name](components_OrgProfileFieldSettings_OrgProfileFieldSettings.InterfaceCustomFieldData.md#name)
- [type](components_OrgProfileFieldSettings_OrgProfileFieldSettings.InterfaceCustomFieldData.md#type)

## Properties

### name

• **name**: `string`

#### Defined in

[src/components/OrgProfileFieldSettings/OrgProfileFieldSettings.tsx:18](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrgProfileFieldSettings/OrgProfileFieldSettings.tsx#L18)

___

### type

• **type**: `string`

#### Defined in

[src/components/OrgProfileFieldSettings/OrgProfileFieldSettings.tsx:17](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrgProfileFieldSettings/OrgProfileFieldSettings.tsx#L17)
