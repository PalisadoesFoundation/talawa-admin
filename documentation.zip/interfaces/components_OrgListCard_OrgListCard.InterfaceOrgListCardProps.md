[talawa-admin](../README.md) / [Modules](../modules.md) / [components/OrgListCard/OrgListCard](../modules/components_OrgListCard_OrgListCard.md) / InterfaceOrgListCardProps

# Interface: InterfaceOrgListCardProps

[components/OrgListCard/OrgListCard](../modules/components_OrgListCard_OrgListCard.md).InterfaceOrgListCardProps

## Table of contents

### Properties

- [data](components_OrgListCard_OrgListCard.InterfaceOrgListCardProps.md#data)

## Properties

### data

• **data**: `InterfaceOrgConnectionInfoType`

#### Defined in

[src/components/OrgListCard/OrgListCard.tsx:14](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrgListCard/OrgListCard.tsx#L14)
