[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPasswordUpdate/UserPasswordUpdate

# Module: components/UserPasswordUpdate/UserPasswordUpdate

## Table of contents

### Functions

- [default](components_UserPasswordUpdate_UserPasswordUpdate.md#default)

## Functions

### default

▸ **default**(`props`, `context?`): ``null`` \| `ReactElement`\<`any`, `any`\>

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `PropsWithChildren`\<`InterfaceUserPasswordUpdateProps`\> |
| `context?` | `any` |

#### Returns

``null`` \| `ReactElement`\<`any`, `any`\>

#### Defined in

[src/components/UserPasswordUpdate/UserPasswordUpdate.tsx:15](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPasswordUpdate/UserPasswordUpdate.tsx#L15)
