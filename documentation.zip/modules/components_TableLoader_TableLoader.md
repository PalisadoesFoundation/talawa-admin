[talawa-admin](../README.md) / [Modules](../modules.md) / components/TableLoader/TableLoader

# Module: components/TableLoader/TableLoader

## Table of contents

### Interfaces

- [InterfaceTableLoader](../interfaces/components_TableLoader_TableLoader.InterfaceTableLoader.md)

### Functions

- [default](components_TableLoader_TableLoader.md#default)

## Functions

### default

▸ **default**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | [`InterfaceTableLoader`](../interfaces/components_TableLoader_TableLoader.InterfaceTableLoader.md) |

#### Returns

`Element`

#### Defined in

[src/components/TableLoader/TableLoader.tsx:11](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/TableLoader/TableLoader.tsx#L11)
