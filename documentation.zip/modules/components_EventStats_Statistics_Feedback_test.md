[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventStats/Statistics/Feedback.test

# Module: components/EventStats/Statistics/Feedback.test
