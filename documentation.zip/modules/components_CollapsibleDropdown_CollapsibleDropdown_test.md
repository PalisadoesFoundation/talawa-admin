[talawa-admin](../README.md) / [Modules](../modules.md) / components/CollapsibleDropdown/CollapsibleDropdown.test

# Module: components/CollapsibleDropdown/CollapsibleDropdown.test
