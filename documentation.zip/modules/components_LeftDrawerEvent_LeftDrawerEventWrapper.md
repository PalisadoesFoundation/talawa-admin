[talawa-admin](../README.md) / [Modules](../modules.md) / components/LeftDrawerEvent/LeftDrawerEventWrapper

# Module: components/LeftDrawerEvent/LeftDrawerEventWrapper

## Table of contents

### Interfaces

- [InterfacePropType](../interfaces/components_LeftDrawerEvent_LeftDrawerEventWrapper.InterfacePropType.md)

### Functions

- [LeftDrawerEventWrapper](components_LeftDrawerEvent_LeftDrawerEventWrapper.md#leftdrawereventwrapper)

## Functions

### LeftDrawerEventWrapper

▸ **LeftDrawerEventWrapper**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | [`InterfacePropType`](../interfaces/components_LeftDrawerEvent_LeftDrawerEventWrapper.InterfacePropType.md) |

#### Returns

`Element`

#### Defined in

[src/components/LeftDrawerEvent/LeftDrawerEventWrapper.tsx:18](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/LeftDrawerEvent/LeftDrawerEventWrapper.tsx#L18)
