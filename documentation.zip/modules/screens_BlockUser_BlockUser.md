[talawa-admin](../README.md) / [Modules](../modules.md) / screens/BlockUser/BlockUser

# Module: screens/BlockUser/BlockUser

## Table of contents

### Functions

- [default](screens_BlockUser_BlockUser.md#default)

## Functions

### default

▸ **default**(): `Element`

#### Returns

`Element`

#### Defined in

[src/screens/BlockUser/BlockUser.tsx:32](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/BlockUser/BlockUser.tsx#L32)
