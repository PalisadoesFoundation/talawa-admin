[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrganizationCardStart/OrganizationCardStart.test

# Module: components/OrganizationCardStart/OrganizationCardStart.test
