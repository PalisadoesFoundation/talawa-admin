[talawa-admin](../README.md) / [Modules](../modules.md) / components/CheckIn/CheckInWrapper

# Module: components/CheckIn/CheckInWrapper

## Table of contents

### Functions

- [CheckInWrapper](components_CheckIn_CheckInWrapper.md#checkinwrapper)

## Functions

### CheckInWrapper

▸ **CheckInWrapper**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `PropType` |

#### Returns

`Element`

#### Defined in

[src/components/CheckIn/CheckInWrapper.tsx:11](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/CheckIn/CheckInWrapper.tsx#L11)
