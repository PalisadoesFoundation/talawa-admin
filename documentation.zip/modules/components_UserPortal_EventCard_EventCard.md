[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/EventCard/EventCard

# Module: components/UserPortal/EventCard/EventCard

## Table of contents

### Functions

- [default](components_UserPortal_EventCard_EventCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceEventCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/EventCard/EventCard.tsx:36](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/EventCard/EventCard.tsx#L36)
