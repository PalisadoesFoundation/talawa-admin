[talawa-admin](../README.md) / [Modules](../modules.md) / components/SuperAdminScreen/SuperAdminScreen

# Module: components/SuperAdminScreen/SuperAdminScreen

## Table of contents

### Interfaces

- [InterfaceSuperAdminScreenProps](../interfaces/components_SuperAdminScreen_SuperAdminScreen.InterfaceSuperAdminScreenProps.md)

### Functions

- [default](components_SuperAdminScreen_SuperAdminScreen.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | [`InterfaceSuperAdminScreenProps`](../interfaces/components_SuperAdminScreen_SuperAdminScreen.InterfaceSuperAdminScreenProps.md) |

#### Returns

`Element`

#### Defined in

[src/components/SuperAdminScreen/SuperAdminScreen.tsx:11](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/SuperAdminScreen/SuperAdminScreen.tsx#L11)
