[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/OrganizationSidebar/OrganizationSidebar.test

# Module: components/UserPortal/OrganizationSidebar/OrganizationSidebar.test
