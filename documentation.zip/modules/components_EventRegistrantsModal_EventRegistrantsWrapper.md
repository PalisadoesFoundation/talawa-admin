[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventRegistrantsModal/EventRegistrantsWrapper

# Module: components/EventRegistrantsModal/EventRegistrantsWrapper

## Table of contents

### Functions

- [EventRegistrantsWrapper](components_EventRegistrantsModal_EventRegistrantsWrapper.md#eventregistrantswrapper)

## Functions

### EventRegistrantsWrapper

▸ **EventRegistrantsWrapper**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `PropType` |

#### Returns

`Element`

#### Defined in

[src/components/EventRegistrantsModal/EventRegistrantsWrapper.tsx:12](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/EventRegistrantsModal/EventRegistrantsWrapper.tsx#L12)
