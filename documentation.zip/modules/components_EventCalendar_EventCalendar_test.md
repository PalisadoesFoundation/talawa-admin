[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventCalendar/EventCalendar.test

# Module: components/EventCalendar/EventCalendar.test
