[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/UserLoginPage/UserLoginPage

# Module: screens/UserPortal/UserLoginPage/UserLoginPage

## Table of contents

### Functions

- [default](screens_UserPortal_UserLoginPage_UserLoginPage.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/UserPortal/UserLoginPage/UserLoginPage.tsx:38](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/UserPortal/UserLoginPage/UserLoginPage.tsx#L38)
