[talawa-admin](../README.md) / [Modules](../modules.md) / components/Advertisements/core/AdvertisementEntry/AdvertisementEntry

# Module: components/Advertisements/core/AdvertisementEntry/AdvertisementEntry

## Table of contents

### Functions

- [default](components_Advertisements_core_AdvertisementEntry_AdvertisementEntry.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | `InterfaceAddOnEntryProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/Advertisements/core/AdvertisementEntry/AdvertisementEntry.tsx:21](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/Advertisements/core/AdvertisementEntry/AdvertisementEntry.tsx#L21)
