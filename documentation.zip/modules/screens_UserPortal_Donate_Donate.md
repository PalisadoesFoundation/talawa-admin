[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/Donate/Donate

# Module: screens/UserPortal/Donate/Donate

## Table of contents

### Functions

- [default](screens_UserPortal_Donate_Donate.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/UserPortal/Donate/Donate.tsx:27](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/UserPortal/Donate/Donate.tsx#L27)
