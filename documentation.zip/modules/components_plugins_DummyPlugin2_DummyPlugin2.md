[talawa-admin](../README.md) / [Modules](../modules.md) / components/plugins/DummyPlugin2/DummyPlugin2

# Module: components/plugins/DummyPlugin2/DummyPlugin2

## Table of contents

### Functions

- [default](components_plugins_DummyPlugin2_DummyPlugin2.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/components/plugins/DummyPlugin2/DummyPlugin2.tsx:4](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/plugins/DummyPlugin2/DummyPlugin2.tsx#L4)
