[talawa-admin](../README.md) / [Modules](../modules.md) / components/AddOn/support/components/SidePanel/SidePanel

# Module: components/AddOn/support/components/SidePanel/SidePanel

## Table of contents

### Functions

- [default](components_AddOn_support_components_SidePanel_SidePanel.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | `InterfaceSidePanelProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/AddOn/support/components/SidePanel/SidePanel.tsx:10](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/AddOn/support/components/SidePanel/SidePanel.tsx#L10)
