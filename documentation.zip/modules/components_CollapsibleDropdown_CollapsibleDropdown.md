[talawa-admin](../README.md) / [Modules](../modules.md) / components/CollapsibleDropdown/CollapsibleDropdown

# Module: components/CollapsibleDropdown/CollapsibleDropdown

## Table of contents

### Interfaces

- [InterfaceCollapsibleDropdown](../interfaces/components_CollapsibleDropdown_CollapsibleDropdown.InterfaceCollapsibleDropdown.md)

### Functions

- [default](components_CollapsibleDropdown_CollapsibleDropdown.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | [`InterfaceCollapsibleDropdown`](../interfaces/components_CollapsibleDropdown_CollapsibleDropdown.InterfaceCollapsibleDropdown.md) |

#### Returns

`Element`

#### Defined in

[src/components/CollapsibleDropdown/CollapsibleDropdown.tsx:13](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/CollapsibleDropdown/CollapsibleDropdown.tsx#L13)
