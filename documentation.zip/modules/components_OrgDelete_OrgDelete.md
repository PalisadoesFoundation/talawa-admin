[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgDelete/OrgDelete

# Module: components/OrgDelete/OrgDelete

## Table of contents

### Functions

- [default](components_OrgDelete_OrgDelete.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/components/OrgDelete/OrgDelete.tsx:4](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrgDelete/OrgDelete.tsx#L4)
