[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrgPost/OrgPost

# Module: screens/OrgPost/OrgPost

## Table of contents

### Functions

- [default](screens_OrgPost_OrgPost.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/OrgPost/OrgPost.tsx:35](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/OrgPost/OrgPost.tsx#L35)
