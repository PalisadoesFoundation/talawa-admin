[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/People/People

# Module: screens/UserPortal/People/People

## Table of contents

### Functions

- [default](screens_UserPortal_People_People.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/UserPortal/People/People.tsx:26](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/UserPortal/People/People.tsx#L26)
