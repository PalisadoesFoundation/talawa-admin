[talawa-admin](../README.md) / [Modules](../modules.md) / components/AddOn/core/AddOnStore/AddOnStore

# Module: components/AddOn/core/AddOnStore/AddOnStore

## Table of contents

### Functions

- [default](components_AddOn_core_AddOnStore_AddOnStore.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/components/AddOn/core/AddOnStore/AddOnStore.tsx:26](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/AddOn/core/AddOnStore/AddOnStore.tsx#L26)
