[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgContriCards/OrgContriCards

# Module: components/OrgContriCards/OrgContriCards

## Table of contents

### Functions

- [default](components_OrgContriCards_OrgContriCards.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceOrgContriCardsProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/OrgContriCards/OrgContriCards.tsx:17](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrgContriCards/OrgContriCards.tsx#L17)
