[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgPostCard/OrgPostCard

# Module: components/OrgPostCard/OrgPostCard

## Table of contents

### Functions

- [default](components_OrgPostCard_OrgPostCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceOrgPostCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/OrgPostCard/OrgPostCard.tsx:35](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrgPostCard/OrgPostCard.tsx#L35)
