[talawa-admin](../README.md) / [Modules](../modules.md) / components/Pagination/Pagination

# Module: components/Pagination/Pagination

## Table of contents

### Functions

- [default](components_Pagination_Pagination.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceTablePaginationActionsProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/Pagination/Pagination.tsx:20](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/Pagination/Pagination.tsx#L20)
