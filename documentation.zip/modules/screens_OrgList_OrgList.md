[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrgList/OrgList

# Module: screens/OrgList/OrgList

## Table of contents

### Functions

- [default](screens_OrgList_OrgList.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/OrgList/OrgList.tsx:33](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/OrgList/OrgList.tsx#L33)
