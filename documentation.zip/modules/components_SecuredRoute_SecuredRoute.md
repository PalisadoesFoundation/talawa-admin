[talawa-admin](../README.md) / [Modules](../modules.md) / components/SecuredRoute/SecuredRoute

# Module: components/SecuredRoute/SecuredRoute

## Table of contents

### Functions

- [default](components_SecuredRoute_SecuredRoute.md#default)

## Functions

### default

▸ **default**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `any` |

#### Returns

`Element`

#### Defined in

[src/components/SecuredRoute/SecuredRoute.tsx:5](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/SecuredRoute/SecuredRoute.tsx#L5)
