[talawa-admin](../README.md) / [Modules](../modules.md) / components/AddOn/support/services/Plugin.helper

# Module: components/AddOn/support/services/Plugin.helper

## Table of contents

### Classes

- [default](../classes/components_AddOn_support_services_Plugin_helper.default.md)
