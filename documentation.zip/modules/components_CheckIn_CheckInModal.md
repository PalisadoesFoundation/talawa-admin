[talawa-admin](../README.md) / [Modules](../modules.md) / components/CheckIn/CheckInModal

# Module: components/CheckIn/CheckInModal

## Table of contents

### Functions

- [CheckInModal](components_CheckIn_CheckInModal.md#checkinmodal)

## Functions

### CheckInModal

▸ **CheckInModal**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | [`InterfaceModalProp`](../interfaces/components_CheckIn_types.InterfaceModalProp.md) |

#### Returns

`Element`

#### Defined in

[src/components/CheckIn/CheckInModal.tsx:16](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/CheckIn/CheckInModal.tsx#L16)
