[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventStats/Statistics/AverageRating.test

# Module: components/EventStats/Statistics/AverageRating.test
