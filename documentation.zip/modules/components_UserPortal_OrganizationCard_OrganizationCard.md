[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/OrganizationCard/OrganizationCard

# Module: components/UserPortal/OrganizationCard/OrganizationCard

## Table of contents

### Functions

- [default](components_UserPortal_OrganizationCard_OrganizationCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceOrganizationCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/OrganizationCard/OrganizationCard.tsx:13](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/OrganizationCard/OrganizationCard.tsx#L13)
