[talawa-admin](../README.md) / [Modules](../modules.md) / components/plugins/DummyPlugin/DummyPlugin

# Module: components/plugins/DummyPlugin/DummyPlugin

## Table of contents

### Functions

- [default](components_plugins_DummyPlugin_DummyPlugin.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/components/plugins/DummyPlugin/DummyPlugin.tsx:5](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/plugins/DummyPlugin/DummyPlugin.tsx#L5)
