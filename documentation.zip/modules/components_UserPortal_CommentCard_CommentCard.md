[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/CommentCard/CommentCard

# Module: components/UserPortal/CommentCard/CommentCard

## Table of contents

### Functions

- [default](components_UserPortal_CommentCard_CommentCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceCommentCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/CommentCard/CommentCard.tsx:26](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/CommentCard/CommentCard.tsx#L26)
