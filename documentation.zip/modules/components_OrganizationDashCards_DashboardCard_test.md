[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrganizationDashCards/DashboardCard.test

# Module: components/OrganizationDashCards/DashboardCard.test
