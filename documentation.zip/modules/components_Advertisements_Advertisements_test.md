[talawa-admin](../README.md) / [Modules](../modules.md) / components/Advertisements/Advertisements.test

# Module: components/Advertisements/Advertisements.test
