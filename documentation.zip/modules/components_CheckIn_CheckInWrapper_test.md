[talawa-admin](../README.md) / [Modules](../modules.md) / components/CheckIn/CheckInWrapper.test

# Module: components/CheckIn/CheckInWrapper.test
