[talawa-admin](../README.md) / [Modules](../modules.md) / components/AddOn/AddOn

# Module: components/AddOn/AddOn

## Table of contents

### Functions

- [default](components_AddOn_AddOn.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | `InterfaceAddOnProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/AddOn/AddOn.tsx:11](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/AddOn/AddOn.tsx#L11)
