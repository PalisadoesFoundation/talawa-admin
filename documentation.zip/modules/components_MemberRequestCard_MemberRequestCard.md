[talawa-admin](../README.md) / [Modules](../modules.md) / components/MemberRequestCard/MemberRequestCard

# Module: components/MemberRequestCard/MemberRequestCard

## Table of contents

### Functions

- [default](components_MemberRequestCard_MemberRequestCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceMemberRequestCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/MemberRequestCard/MemberRequestCard.tsx:26](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/MemberRequestCard/MemberRequestCard.tsx#L26)
