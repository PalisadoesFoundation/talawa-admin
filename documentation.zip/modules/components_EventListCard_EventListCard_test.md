[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventListCard/EventListCard.test

# Module: components/EventListCard/EventListCard.test
