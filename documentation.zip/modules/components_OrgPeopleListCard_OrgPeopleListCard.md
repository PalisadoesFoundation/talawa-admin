[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgPeopleListCard/OrgPeopleListCard

# Module: components/OrgPeopleListCard/OrgPeopleListCard

## Table of contents

### Functions

- [default](components_OrgPeopleListCard_OrgPeopleListCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceOrgPeopleListCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/OrgPeopleListCard/OrgPeopleListCard.tsx:24](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrgPeopleListCard/OrgPeopleListCard.tsx#L24)
