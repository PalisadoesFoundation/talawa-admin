[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/People/People.test

# Module: screens/UserPortal/People/People.test
