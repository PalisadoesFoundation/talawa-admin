[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/ContactCard/ContactCard

# Module: components/UserPortal/ContactCard/ContactCard

## Table of contents

### Functions

- [default](components_UserPortal_ContactCard_ContactCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceContactCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/ContactCard/ContactCard.tsx:15](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/ContactCard/ContactCard.tsx#L15)
