[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventStats/EventStatsWrapper

# Module: components/EventStats/EventStatsWrapper

## Table of contents

### Functions

- [EventStatsWrapper](components_EventStats_EventStatsWrapper.md#eventstatswrapper)

## Functions

### EventStatsWrapper

▸ **EventStatsWrapper**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `PropType` |

#### Returns

`Element`

#### Defined in

[src/components/EventStats/EventStatsWrapper.tsx:11](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/EventStats/EventStatsWrapper.tsx#L11)
