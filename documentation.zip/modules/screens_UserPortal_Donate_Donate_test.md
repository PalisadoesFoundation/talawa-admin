[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/Donate/Donate.test

# Module: screens/UserPortal/Donate/Donate.test
