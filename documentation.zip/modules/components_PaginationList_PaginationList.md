[talawa-admin](../README.md) / [Modules](../modules.md) / components/PaginationList/PaginationList

# Module: components/PaginationList/PaginationList

## Table of contents

### Functions

- [default](components_PaginationList_PaginationList.md#default)

## Functions

### default

▸ **default**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfacePropsInterface` |

#### Returns

`Element`

#### Defined in

[src/components/PaginationList/PaginationList.tsx:21](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/PaginationList/PaginationList.tsx#L21)
