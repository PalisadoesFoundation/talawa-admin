[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/DonationCard/DonationCard

# Module: components/UserPortal/DonationCard/DonationCard

## Table of contents

### Functions

- [default](components_UserPortal_DonationCard_DonationCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceDonationCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/DonationCard/DonationCard.tsx:12](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/DonationCard/DonationCard.tsx#L12)
