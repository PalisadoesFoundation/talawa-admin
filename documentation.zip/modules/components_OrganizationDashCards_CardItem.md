[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrganizationDashCards/CardItem

# Module: components/OrganizationDashCards/CardItem

## Table of contents

### Interfaces

- [InterfaceCardItem](../interfaces/components_OrganizationDashCards_CardItem.InterfaceCardItem.md)

### Functions

- [default](components_OrganizationDashCards_CardItem.md#default)

## Functions

### default

▸ **default**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | [`InterfaceCardItem`](../interfaces/components_OrganizationDashCards_CardItem.InterfaceCardItem.md) |

#### Returns

`Element`

#### Defined in

[src/components/OrganizationDashCards/CardItem.tsx:21](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrganizationDashCards/CardItem.tsx#L21)
