[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrgList/OrgList.test

# Module: screens/OrgList/OrgList.test
