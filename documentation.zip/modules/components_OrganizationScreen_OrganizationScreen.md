[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrganizationScreen/OrganizationScreen

# Module: components/OrganizationScreen/OrganizationScreen

## Table of contents

### Interfaces

- [InterfaceOrganizationScreenProps](../interfaces/components_OrganizationScreen_OrganizationScreen.InterfaceOrganizationScreenProps.md)

### Functions

- [default](components_OrganizationScreen_OrganizationScreen.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | [`InterfaceOrganizationScreenProps`](../interfaces/components_OrganizationScreen_OrganizationScreen.InterfaceOrganizationScreenProps.md) |

#### Returns

`Element`

#### Defined in

[src/components/OrganizationScreen/OrganizationScreen.tsx:14](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrganizationScreen/OrganizationScreen.tsx#L14)
