[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgProfileFieldSettings/OrgProfileFieldSettings

# Module: components/OrgProfileFieldSettings/OrgProfileFieldSettings

## Table of contents

### Interfaces

- [InterfaceCustomFieldData](../interfaces/components_OrgProfileFieldSettings_OrgProfileFieldSettings.InterfaceCustomFieldData.md)

### Functions

- [default](components_OrgProfileFieldSettings_OrgProfileFieldSettings.md#default)

## Functions

### default

▸ **default**(): `any`

#### Returns

`any`

#### Defined in

[src/components/OrgProfileFieldSettings/OrgProfileFieldSettings.tsx:21](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrgProfileFieldSettings/OrgProfileFieldSettings.tsx#L21)
