[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPasswordUpdate/UserPasswordUpdate.test

# Module: components/UserPasswordUpdate/UserPasswordUpdate.test
