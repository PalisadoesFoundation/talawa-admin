[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrgSettings/OrgSettings.test

# Module: screens/OrgSettings/OrgSettings.test
