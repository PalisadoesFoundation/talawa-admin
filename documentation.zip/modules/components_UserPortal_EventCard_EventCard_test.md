[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/EventCard/EventCard.test

# Module: components/UserPortal/EventCard/EventCard.test
