[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/Events/Events.test

# Module: screens/UserPortal/Events/Events.test
