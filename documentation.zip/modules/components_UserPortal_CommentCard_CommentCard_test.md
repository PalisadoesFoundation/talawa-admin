[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/CommentCard/CommentCard.test

# Module: components/UserPortal/CommentCard/CommentCard.test
