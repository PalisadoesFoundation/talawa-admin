[talawa-admin](../README.md) / [Modules](../modules.md) / components/CheckIn/types

# Module: components/CheckIn/types

## Table of contents

### Interfaces

- [InterfaceAttendeeCheckIn](../interfaces/components_CheckIn_types.InterfaceAttendeeCheckIn.md)
- [InterfaceAttendeeQueryResponse](../interfaces/components_CheckIn_types.InterfaceAttendeeQueryResponse.md)
- [InterfaceModalProp](../interfaces/components_CheckIn_types.InterfaceModalProp.md)
- [InterfaceTableCheckIn](../interfaces/components_CheckIn_types.InterfaceTableCheckIn.md)
- [InterfaceTableData](../interfaces/components_CheckIn_types.InterfaceTableData.md)
- [InterfaceUser](../interfaces/components_CheckIn_types.InterfaceUser.md)
