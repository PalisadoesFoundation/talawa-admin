[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgListCard/OrgListCard.test

# Module: components/OrgListCard/OrgListCard.test
