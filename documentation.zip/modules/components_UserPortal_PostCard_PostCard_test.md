[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/PostCard/PostCard.test

# Module: components/UserPortal/PostCard/PostCard.test
