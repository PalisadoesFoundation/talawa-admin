[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/UserSidebar/UserSidebar

# Module: components/UserPortal/UserSidebar/UserSidebar

## Table of contents

### Functions

- [default](components_UserPortal_UserSidebar_UserSidebar.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/UserSidebar/UserSidebar.tsx:15](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/UserSidebar/UserSidebar.tsx#L15)
