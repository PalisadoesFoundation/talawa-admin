[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/Login/Login

# Module: components/UserPortal/Login/Login

## Table of contents

### Functions

- [default](components_UserPortal_Login_Login.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceLoginProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/Login/Login.tsx:19](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/Login/Login.tsx#L19)
