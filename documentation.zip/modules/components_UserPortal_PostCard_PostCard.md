[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/PostCard/PostCard

# Module: components/UserPortal/PostCard/PostCard

## Table of contents

### Functions

- [default](components_UserPortal_PostCard_PostCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfacePostCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/PostCard/PostCard.tsx:70](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/PostCard/PostCard.tsx#L70)
