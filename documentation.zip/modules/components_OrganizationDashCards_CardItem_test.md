[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrganizationDashCards/CardItem.test

# Module: components/OrganizationDashCards/CardItem.test
