[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventRegistrantsModal/EventRegistrantsModal.test

# Module: components/EventRegistrantsModal/EventRegistrantsModal.test
