[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrganizationEvents/OrganizationEvents

# Module: screens/OrganizationEvents/OrganizationEvents

## Table of contents

### Functions

- [default](screens_OrganizationEvents_OrganizationEvents.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/OrganizationEvents/OrganizationEvents.tsx:23](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/OrganizationEvents/OrganizationEvents.tsx#L23)
