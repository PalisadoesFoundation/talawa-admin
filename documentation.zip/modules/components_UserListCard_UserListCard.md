[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserListCard/UserListCard

# Module: components/UserListCard/UserListCard

## Table of contents

### Functions

- [default](components_UserListCard_UserListCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceUserListCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserListCard/UserListCard.tsx:24](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserListCard/UserListCard.tsx#L24)
