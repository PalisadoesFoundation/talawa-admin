[talawa-admin](../README.md) / [Modules](../modules.md) / screens/PageNotFound/PageNotFound

# Module: screens/PageNotFound/PageNotFound

## Table of contents

### Functions

- [default](screens_PageNotFound_PageNotFound.md#default)

## Functions

### default

▸ **default**(): `Element`

#### Returns

`Element`

#### Defined in

[src/screens/PageNotFound/PageNotFound.tsx:8](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/PageNotFound/PageNotFound.tsx#L8)
