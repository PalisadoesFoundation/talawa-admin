[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrganizationScreen/OrganizationScreen.test

# Module: components/OrganizationScreen/OrganizationScreen.test
