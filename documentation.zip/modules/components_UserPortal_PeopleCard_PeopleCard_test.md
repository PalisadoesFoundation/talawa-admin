[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/PeopleCard/PeopleCard.test

# Module: components/UserPortal/PeopleCard/PeopleCard.test
