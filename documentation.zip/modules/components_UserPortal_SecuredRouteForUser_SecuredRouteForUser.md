[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/SecuredRouteForUser/SecuredRouteForUser

# Module: components/UserPortal/SecuredRouteForUser/SecuredRouteForUser

## Table of contents

### Functions

- [default](components_UserPortal_SecuredRouteForUser_SecuredRouteForUser.md#default)

## Functions

### default

▸ **default**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `any` |

#### Returns

`Element`

#### Defined in

[src/components/UserPortal/SecuredRouteForUser/SecuredRouteForUser.tsx:4](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/SecuredRouteForUser/SecuredRouteForUser.tsx#L4)
