[talawa-admin](../README.md) / [Modules](../modules.md) / components/TableLoader/TableLoader.test

# Module: components/TableLoader/TableLoader.test
