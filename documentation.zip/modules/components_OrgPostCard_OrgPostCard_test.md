[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgPostCard/OrgPostCard.test

# Module: components/OrgPostCard/OrgPostCard.test
