[talawa-admin](../README.md) / [Modules](../modules.md) / components/Pagination/Pagination.test

# Module: components/Pagination/Pagination.test
