[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/Organizations/Organizations

# Module: screens/UserPortal/Organizations/Organizations

## Table of contents

### Functions

- [default](screens_UserPortal_Organizations_Organizations.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/UserPortal/Organizations/Organizations.tsx:24](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/UserPortal/Organizations/Organizations.tsx#L24)
