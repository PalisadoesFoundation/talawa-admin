[talawa-admin](../README.md) / [Modules](../modules.md) / components/Advertisements/core/AdvertisementEntry/AdvertisementEntry.test

# Module: components/Advertisements/core/AdvertisementEntry/AdvertisementEntry.test
