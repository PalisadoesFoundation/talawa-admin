[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/Settings/Settings

# Module: screens/UserPortal/Settings/Settings

## Table of contents

### Functions

- [default](screens_UserPortal_Settings_Settings.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/UserPortal/Settings/Settings.tsx:15](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/UserPortal/Settings/Settings.tsx#L15)
