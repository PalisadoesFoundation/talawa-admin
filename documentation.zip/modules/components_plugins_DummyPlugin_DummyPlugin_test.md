[talawa-admin](../README.md) / [Modules](../modules.md) / components/plugins/DummyPlugin/DummyPlugin.test

# Module: components/plugins/DummyPlugin/DummyPlugin.test
