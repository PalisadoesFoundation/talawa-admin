[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgUpdate/OrgUpdate

# Module: components/OrgUpdate/OrgUpdate

## Table of contents

### Functions

- [default](components_OrgUpdate_OrgUpdate.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceOrgUpdateProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/OrgUpdate/OrgUpdate.tsx:22](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrgUpdate/OrgUpdate.tsx#L22)
