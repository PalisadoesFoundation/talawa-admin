[talawa-admin](../README.md) / [Modules](../modules.md) / components/AddOn/support/components/Action/Action

# Module: components/AddOn/support/components/Action/Action

## Table of contents

### Functions

- [default](components_AddOn_support_components_Action_Action.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceActionProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/AddOn/support/components/Action/Action.tsx:10](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/AddOn/support/components/Action/Action.tsx#L10)
