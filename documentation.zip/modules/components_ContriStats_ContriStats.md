[talawa-admin](../README.md) / [Modules](../modules.md) / components/ContriStats/ContriStats

# Module: components/ContriStats/ContriStats

## Table of contents

### Functions

- [default](components_ContriStats_ContriStats.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceContriStatsProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/ContriStats/ContriStats.tsx:14](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/ContriStats/ContriStats.tsx#L14)
