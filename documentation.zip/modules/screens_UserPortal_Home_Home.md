[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/Home/Home

# Module: screens/UserPortal/Home/Home

## Table of contents

### Functions

- [default](screens_UserPortal_Home_Home.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/UserPortal/Home/Home.tsx:78](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/UserPortal/Home/Home.tsx#L78)
