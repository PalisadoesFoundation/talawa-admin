[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/Settings/Settings.test

# Module: screens/UserPortal/Settings/Settings.test
