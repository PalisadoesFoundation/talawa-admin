[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrgSettings/OrgSettings

# Module: screens/OrgSettings/OrgSettings

## Table of contents

### Functions

- [default](screens_OrgSettings_OrgSettings.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/OrgSettings/OrgSettings.tsx:13](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/OrgSettings/OrgSettings.tsx#L13)
