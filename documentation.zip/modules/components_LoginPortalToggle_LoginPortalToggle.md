[talawa-admin](../README.md) / [Modules](../modules.md) / components/LoginPortalToggle/LoginPortalToggle

# Module: components/LoginPortalToggle/LoginPortalToggle

## Table of contents

### Functions

- [default](components_LoginPortalToggle_LoginPortalToggle.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/components/LoginPortalToggle/LoginPortalToggle.tsx:8](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/LoginPortalToggle/LoginPortalToggle.tsx#L8)
