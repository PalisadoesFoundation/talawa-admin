[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrganizationCard/OrganizationCard.test

# Module: components/OrganizationCard/OrganizationCard.test
