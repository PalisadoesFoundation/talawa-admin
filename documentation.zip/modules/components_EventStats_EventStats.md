[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventStats/EventStats

# Module: components/EventStats/EventStats

## Table of contents

### Functions

- [EventStats](components_EventStats_EventStats.md#eventstats)

## Functions

### EventStats

▸ **EventStats**(`«destructured»`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | `ModalPropType` |

#### Returns

`Element`

#### Defined in

[src/components/EventStats/EventStats.tsx:17](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/EventStats/EventStats.tsx#L17)
