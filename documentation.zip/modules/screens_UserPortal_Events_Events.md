[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/Events/Events

# Module: screens/UserPortal/Events/Events

## Table of contents

### Functions

- [default](screens_UserPortal_Events_Events.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/UserPortal/Events/Events.tsx:49](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/UserPortal/Events/Events.tsx#L49)
