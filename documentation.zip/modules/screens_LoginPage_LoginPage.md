[talawa-admin](../README.md) / [Modules](../modules.md) / screens/LoginPage/LoginPage

# Module: screens/LoginPage/LoginPage

## Table of contents

### Functions

- [default](screens_LoginPage_LoginPage.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/LoginPage/LoginPage.tsx:39](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/LoginPage/LoginPage.tsx#L39)
