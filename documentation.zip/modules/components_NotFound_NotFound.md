[talawa-admin](../README.md) / [Modules](../modules.md) / components/NotFound/NotFound

# Module: components/NotFound/NotFound

## Table of contents

### Functions

- [default](components_NotFound_NotFound.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceNotFoundProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/NotFound/NotFound.tsx:11](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/NotFound/NotFound.tsx#L11)
