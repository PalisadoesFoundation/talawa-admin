[talawa-admin](../README.md) / [Modules](../modules.md) / components/SuperAdminScreen/SuperAdminScreen.test

# Module: components/SuperAdminScreen/SuperAdminScreen.test
