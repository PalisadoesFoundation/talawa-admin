[talawa-admin](../README.md) / [Modules](../modules.md) / components/CheckIn/CheckInModal.test

# Module: components/CheckIn/CheckInModal.test
