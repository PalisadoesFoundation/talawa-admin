[talawa-admin](../README.md) / [Modules](../modules.md) / components/DeleteOrg/DeleteOrg.test

# Module: components/DeleteOrg/DeleteOrg.test
