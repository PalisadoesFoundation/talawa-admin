[talawa-admin](../README.md) / [Modules](../modules.md) / components/CheckIn/TableRow.test

# Module: components/CheckIn/TableRow.test
