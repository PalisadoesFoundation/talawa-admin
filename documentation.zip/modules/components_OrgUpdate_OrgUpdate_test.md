[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgUpdate/OrgUpdate.test

# Module: components/OrgUpdate/OrgUpdate.test
