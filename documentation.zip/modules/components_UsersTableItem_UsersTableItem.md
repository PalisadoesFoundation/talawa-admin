[talawa-admin](../README.md) / [Modules](../modules.md) / components/UsersTableItem/UsersTableItem

# Module: components/UsersTableItem/UsersTableItem

## Table of contents

### Functions

- [default](components_UsersTableItem_UsersTableItem.md#default)

## Functions

### default

▸ **default**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `Props` |

#### Returns

`Element`

#### Defined in

[src/components/UsersTableItem/UsersTableItem.tsx:25](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UsersTableItem/UsersTableItem.tsx#L25)
