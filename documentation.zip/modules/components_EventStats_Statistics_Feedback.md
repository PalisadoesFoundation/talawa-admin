[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventStats/Statistics/Feedback

# Module: components/EventStats/Statistics/Feedback

## Table of contents

### Functions

- [FeedbackStats](components_EventStats_Statistics_Feedback.md#feedbackstats)

## Functions

### FeedbackStats

▸ **FeedbackStats**(`«destructured»`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | `ModalPropType` |

#### Returns

`Element`

#### Defined in

[src/components/EventStats/Statistics/Feedback.tsx:25](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/EventStats/Statistics/Feedback.tsx#L25)
