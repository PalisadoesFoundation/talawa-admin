[talawa-admin](../README.md) / [Modules](../modules.md) / screens/EventDashboard/EventDashboard.test

# Module: screens/EventDashboard/EventDashboard.test
