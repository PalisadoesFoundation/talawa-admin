[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrganizationCardStart/OrganizationCardStart

# Module: components/OrganizationCardStart/OrganizationCardStart

## Table of contents

### Functions

- [default](components_OrganizationCardStart_OrganizationCardStart.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceOrganizationCardStartProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/OrganizationCardStart/OrganizationCardStart.tsx:11](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrganizationCardStart/OrganizationCardStart.tsx#L11)
