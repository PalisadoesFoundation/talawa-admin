[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/Organizations/Organizations.test

# Module: screens/UserPortal/Organizations/Organizations.test
