[talawa-admin](../README.md) / [Modules](../modules.md) / components/UsersTableItem/UserTableItem.test

# Module: components/UsersTableItem/UserTableItem.test
