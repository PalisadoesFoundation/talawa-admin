[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgAdminListCard/OrgAdminListCard.test

# Module: components/OrgAdminListCard/OrgAdminListCard.test
