[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgPeopleListCard/OrgPeopleListCard.test

# Module: components/OrgPeopleListCard/OrgPeopleListCard.test
