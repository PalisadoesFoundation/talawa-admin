[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventRegistrantsModal/EventRegistrantsModal

# Module: components/EventRegistrantsModal/EventRegistrantsModal

## Table of contents

### Functions

- [EventRegistrantsModal](components_EventRegistrantsModal_EventRegistrantsModal.md#eventregistrantsmodal)

## Functions

### EventRegistrantsModal

▸ **EventRegistrantsModal**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `ModalPropType` |

#### Returns

`Element`

#### Defined in

[src/components/EventRegistrantsModal/EventRegistrantsModal.tsx:30](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/EventRegistrantsModal/EventRegistrantsModal.tsx#L30)
