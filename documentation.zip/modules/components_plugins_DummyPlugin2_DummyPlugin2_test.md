[talawa-admin](../README.md) / [Modules](../modules.md) / components/plugins/DummyPlugin2/DummyPlugin2.test

# Module: components/plugins/DummyPlugin2/DummyPlugin2.test
