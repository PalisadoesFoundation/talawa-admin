[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserUpdate/UserUpdate.test

# Module: components/UserUpdate/UserUpdate.test
