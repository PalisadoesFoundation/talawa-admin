[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/PromotedPost/PromotedPost

# Module: components/UserPortal/PromotedPost/PromotedPost

## Table of contents

### Functions

- [default](components_UserPortal_PromotedPost_PromotedPost.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfacePostCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/PromotedPost/PromotedPost.tsx:10](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/PromotedPost/PromotedPost.tsx#L10)
