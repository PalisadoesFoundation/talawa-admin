[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrganizationEvents/OrganizationEvents.test

# Module: screens/OrganizationEvents/OrganizationEvents.test
