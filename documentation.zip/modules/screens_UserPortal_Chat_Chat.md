[talawa-admin](../README.md) / [Modules](../modules.md) / screens/UserPortal/Chat/Chat

# Module: screens/UserPortal/Chat/Chat

## Table of contents

### Functions

- [default](screens_UserPortal_Chat_Chat.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/UserPortal/Chat/Chat.tsx:30](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/UserPortal/Chat/Chat.tsx#L30)
