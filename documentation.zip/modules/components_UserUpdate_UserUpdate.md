[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserUpdate/UserUpdate

# Module: components/UserUpdate/UserUpdate

## Table of contents

### Functions

- [default](components_UserUpdate_UserUpdate.md#default)

## Functions

### default

▸ **default**(`props`, `context?`): ``null`` \| `ReactElement`\<`any`, `any`\>

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `PropsWithChildren`\<`InterfaceUserUpdateProps`\> |
| `context?` | `any` |

#### Returns

``null`` \| `ReactElement`\<`any`, `any`\>

#### Defined in

[src/components/UserUpdate/UserUpdate.tsx:23](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserUpdate/UserUpdate.tsx#L23)
