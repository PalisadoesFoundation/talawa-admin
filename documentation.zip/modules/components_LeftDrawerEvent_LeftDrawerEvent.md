[talawa-admin](../README.md) / [Modules](../modules.md) / components/LeftDrawerEvent/LeftDrawerEvent

# Module: components/LeftDrawerEvent/LeftDrawerEvent

## Table of contents

### Interfaces

- [InterfaceLeftDrawerProps](../interfaces/components_LeftDrawerEvent_LeftDrawerEvent.InterfaceLeftDrawerProps.md)

### Functions

- [default](components_LeftDrawerEvent_LeftDrawerEvent.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | [`InterfaceLeftDrawerProps`](../interfaces/components_LeftDrawerEvent_LeftDrawerEvent.InterfaceLeftDrawerProps.md) |

#### Returns

`Element`

#### Defined in

[src/components/LeftDrawerEvent/LeftDrawerEvent.tsx:28](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/LeftDrawerEvent/LeftDrawerEvent.tsx#L28)
