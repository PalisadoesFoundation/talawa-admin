[talawa-admin](../README.md) / [Modules](../modules.md) / components/IconComponent/IconComponent.test

# Module: components/IconComponent/IconComponent.test
