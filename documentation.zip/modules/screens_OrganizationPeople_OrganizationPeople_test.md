[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrganizationPeople/OrganizationPeople.test

# Module: screens/OrganizationPeople/OrganizationPeople.test
