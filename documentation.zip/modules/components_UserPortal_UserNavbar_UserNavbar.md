[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/UserNavbar/UserNavbar

# Module: components/UserPortal/UserNavbar/UserNavbar

## Table of contents

### Functions

- [default](components_UserPortal_UserNavbar_UserNavbar.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/UserNavbar/UserNavbar.tsx:15](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/UserNavbar/UserNavbar.tsx#L15)
