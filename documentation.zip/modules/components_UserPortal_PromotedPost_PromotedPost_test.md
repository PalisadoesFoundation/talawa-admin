[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/PromotedPost/PromotedPost.test

# Module: components/UserPortal/PromotedPost/PromotedPost.test
