[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/Register/Register

# Module: components/UserPortal/Register/Register

## Table of contents

### Functions

- [default](components_UserPortal_Register_Register.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceRegisterProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/Register/Register.tsx:19](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/Register/Register.tsx#L19)
