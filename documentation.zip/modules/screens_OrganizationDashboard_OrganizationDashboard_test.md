[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrganizationDashboard/OrganizationDashboard.test

# Module: screens/OrganizationDashboard/OrganizationDashboard.test
