[talawa-admin](../README.md) / [Modules](../modules.md) / components/plugins

# Module: components/plugins

## Table of contents

### References

- [DummyPlugin](components_plugins.md#dummyplugin)
- [DummyPlugin2](components_plugins.md#dummyplugin2)

## References

### DummyPlugin

Renames and re-exports [default](components_plugins_DummyPlugin_DummyPlugin.md#default)

___

### DummyPlugin2

Renames and re-exports [default](components_plugins_DummyPlugin2_DummyPlugin2.md#default)
