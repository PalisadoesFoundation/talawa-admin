[talawa-admin](../README.md) / [Modules](../modules.md) / components/Advertisements/core/AdvertisementRegister/AdvertisementRegister.test

# Module: components/Advertisements/core/AdvertisementRegister/AdvertisementRegister.test
