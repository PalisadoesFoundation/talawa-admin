[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrganizationCard/OrganizationCard

# Module: components/OrganizationCard/OrganizationCard

## Table of contents

### Functions

- [default](components_OrganizationCard_OrganizationCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceOrganizationCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/OrganizationCard/OrganizationCard.tsx:13](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrganizationCard/OrganizationCard.tsx#L13)
