[talawa-admin](../README.md) / [Modules](../modules.md) / screens/MemberDetail/MemberDetail.test

# Module: screens/MemberDetail/MemberDetail.test
