[talawa-admin](../README.md) / [Modules](../modules.md) / components/CheckIn/tagTemplate

# Module: components/CheckIn/tagTemplate

## Table of contents

### Variables

- [tagTemplate](components_CheckIn_tagTemplate.md#tagtemplate)

## Variables

### tagTemplate

• `Const` **tagTemplate**: `Template`

#### Defined in

[src/components/CheckIn/tagTemplate.ts:3](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/CheckIn/tagTemplate.ts#L3)
