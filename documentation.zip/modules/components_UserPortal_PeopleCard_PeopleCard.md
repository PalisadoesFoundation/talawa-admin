[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/PeopleCard/PeopleCard

# Module: components/UserPortal/PeopleCard/PeopleCard

## Table of contents

### Functions

- [default](components_UserPortal_PeopleCard_PeopleCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceOrganizationCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/PeopleCard/PeopleCard.tsx:12](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/PeopleCard/PeopleCard.tsx#L12)
