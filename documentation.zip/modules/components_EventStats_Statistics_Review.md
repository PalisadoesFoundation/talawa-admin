[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventStats/Statistics/Review

# Module: components/EventStats/Statistics/Review

## Table of contents

### Functions

- [ReviewStats](components_EventStats_Statistics_Review.md#reviewstats)

## Functions

### ReviewStats

▸ **ReviewStats**(`«destructured»`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | `ModalPropType` |

#### Returns

`Element`

#### Defined in

[src/components/EventStats/Statistics/Review.tsx:21](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/EventStats/Statistics/Review.tsx#L21)
