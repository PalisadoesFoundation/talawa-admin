[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/ChatRoom/ChatRoom

# Module: components/UserPortal/ChatRoom/ChatRoom

## Table of contents

### Functions

- [default](components_UserPortal_ChatRoom_ChatRoom.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceChatRoomProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/ChatRoom/ChatRoom.tsx:14](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/ChatRoom/ChatRoom.tsx#L14)
