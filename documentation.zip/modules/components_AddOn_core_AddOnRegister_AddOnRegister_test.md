[talawa-admin](../README.md) / [Modules](../modules.md) / components/AddOn/core/AddOnRegister/AddOnRegister.test

# Module: components/AddOn/core/AddOnRegister/AddOnRegister.test
