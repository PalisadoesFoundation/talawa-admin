[talawa-admin](../README.md) / [Modules](../modules.md) / components/IconComponent/IconComponent

# Module: components/IconComponent/IconComponent

## Table of contents

### Interfaces

- [InterfaceIconComponent](../interfaces/components_IconComponent_IconComponent.InterfaceIconComponent.md)

### Functions

- [default](components_IconComponent_IconComponent.md#default)

## Functions

### default

▸ **default**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | [`InterfaceIconComponent`](../interfaces/components_IconComponent_IconComponent.InterfaceIconComponent.md) |

#### Returns

`Element`

#### Defined in

[src/components/IconComponent/IconComponent.tsx:22](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/IconComponent/IconComponent.tsx#L22)
