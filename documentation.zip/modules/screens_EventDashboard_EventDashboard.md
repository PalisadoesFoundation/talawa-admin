[talawa-admin](../README.md) / [Modules](../modules.md) / screens/EventDashboard/EventDashboard

# Module: screens/EventDashboard/EventDashboard

## Table of contents

### Functions

- [default](screens_EventDashboard_EventDashboard.md#default)

## Functions

### default

▸ **default**(): `Element`

#### Returns

`Element`

#### Defined in

[src/screens/EventDashboard/EventDashboard.tsx:10](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/EventDashboard/EventDashboard.tsx#L10)
