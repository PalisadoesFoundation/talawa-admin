[talawa-admin](../README.md) / [Modules](../modules.md) / components/DeleteOrg/DeleteOrg

# Module: components/DeleteOrg/DeleteOrg

## Table of contents

### Functions

- [default](components_DeleteOrg_DeleteOrg.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/components/DeleteOrg/DeleteOrg.tsx:14](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/DeleteOrg/DeleteOrg.tsx#L14)
