[talawa-admin](../README.md) / [Modules](../modules.md) / components/AddOn/core/AddOnRegister/AddOnRegister

# Module: components/AddOn/core/AddOnRegister/AddOnRegister

## Table of contents

### Functions

- [default](components_AddOn_core_AddOnRegister_AddOnRegister.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | `InterfaceAddOnRegisterProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/AddOn/core/AddOnRegister/AddOnRegister.tsx:24](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/AddOn/core/AddOnRegister/AddOnRegister.tsx#L24)
