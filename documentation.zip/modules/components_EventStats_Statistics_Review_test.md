[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventStats/Statistics/Review.test

# Module: components/EventStats/Statistics/Review.test
