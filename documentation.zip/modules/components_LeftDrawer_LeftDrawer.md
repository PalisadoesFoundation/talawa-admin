[talawa-admin](../README.md) / [Modules](../modules.md) / components/LeftDrawer/LeftDrawer

# Module: components/LeftDrawer/LeftDrawer

## Table of contents

### Interfaces

- [InterfaceLeftDrawerProps](../interfaces/components_LeftDrawer_LeftDrawer.InterfaceLeftDrawerProps.md)

### Functions

- [default](components_LeftDrawer_LeftDrawer.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | [`InterfaceLeftDrawerProps`](../interfaces/components_LeftDrawer_LeftDrawer.InterfaceLeftDrawerProps.md) |

#### Returns

`Element`

#### Defined in

[src/components/LeftDrawer/LeftDrawer.tsx:20](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/LeftDrawer/LeftDrawer.tsx#L20)
