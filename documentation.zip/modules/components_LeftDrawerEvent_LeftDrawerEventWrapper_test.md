[talawa-admin](../README.md) / [Modules](../modules.md) / components/LeftDrawerEvent/LeftDrawerEventWrapper.test

# Module: components/LeftDrawerEvent/LeftDrawerEventWrapper.test
