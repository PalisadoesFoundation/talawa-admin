[talawa-admin](../README.md) / [Modules](../modules.md) / components/Advertisements/core/AdvertisementRegister/AdvertisementRegister

# Module: components/Advertisements/core/AdvertisementRegister/AdvertisementRegister

## Table of contents

### Functions

- [default](components_Advertisements_core_AdvertisementRegister_AdvertisementRegister.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | `InterfaceAddOnRegisterProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/Advertisements/core/AdvertisementRegister/AdvertisementRegister.tsx:36](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/Advertisements/core/AdvertisementRegister/AdvertisementRegister.tsx#L36)
