[talawa-admin](../README.md) / [Modules](../modules.md) / components/EditCustomFieldDropDown/EditCustomFieldDropDown

# Module: components/EditCustomFieldDropDown/EditCustomFieldDropDown

## Table of contents

### Functions

- [default](components_EditCustomFieldDropDown_EditCustomFieldDropDown.md#default)

## Functions

### default

▸ **default**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceEditCustomFieldDropDownProps` |

#### Returns

`Element`

#### Defined in

[src/components/EditCustomFieldDropDown/EditCustomFieldDropDown.tsx:16](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/EditCustomFieldDropDown/EditCustomFieldDropDown.tsx#L16)
