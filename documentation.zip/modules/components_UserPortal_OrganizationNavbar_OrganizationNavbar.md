[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/OrganizationNavbar/OrganizationNavbar

# Module: components/UserPortal/OrganizationNavbar/OrganizationNavbar

## Table of contents

### Functions

- [default](components_UserPortal_OrganizationNavbar_OrganizationNavbar.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceNavbarProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/OrganizationNavbar/OrganizationNavbar.tsx:29](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/OrganizationNavbar/OrganizationNavbar.tsx#L29)
