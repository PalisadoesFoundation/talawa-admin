[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/SecuredRouteForUser/SecuredRouteForUser.test

# Module: components/UserPortal/SecuredRouteForUser/SecuredRouteForUser.test
