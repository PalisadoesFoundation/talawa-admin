[talawa-admin](../README.md) / [Modules](../modules.md) / components/LeftDrawerEvent/LeftDrawerEvent.test

# Module: components/LeftDrawerEvent/LeftDrawerEvent.test
