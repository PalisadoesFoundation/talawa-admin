[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrganizationDashboard/OrganizationDashboard

# Module: screens/OrganizationDashboard/OrganizationDashboard

## Table of contents

### Functions

- [default](screens_OrganizationDashboard_OrganizationDashboard.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/OrganizationDashboard/OrganizationDashboard.tsx:32](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/OrganizationDashboard/OrganizationDashboard.tsx#L32)
