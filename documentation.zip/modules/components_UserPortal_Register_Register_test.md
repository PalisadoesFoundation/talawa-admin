[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/Register/Register.test

# Module: components/UserPortal/Register/Register.test
