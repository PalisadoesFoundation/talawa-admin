[talawa-admin](../README.md) / [Modules](../modules.md) / components/Loader/Loader.test

# Module: components/Loader/Loader.test
