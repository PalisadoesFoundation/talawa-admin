[talawa-admin](../README.md) / [Modules](../modules.md) / components/AddOn/core/AddOnEntry/AddOnEntry

# Module: components/AddOn/core/AddOnEntry/AddOnEntry

## Table of contents

### Functions

- [default](components_AddOn_core_AddOnEntry_AddOnEntry.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | `InterfaceAddOnEntryProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/AddOn/core/AddOnEntry/AddOnEntry.tsx:22](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/AddOn/core/AddOnEntry/AddOnEntry.tsx#L22)
