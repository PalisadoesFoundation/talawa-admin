[talawa-admin](../README.md) / [Modules](../modules.md) / components/LeftDrawerOrg/LeftDrawerOrg

# Module: components/LeftDrawerOrg/LeftDrawerOrg

## Table of contents

### Interfaces

- [InterfaceLeftDrawerProps](../interfaces/components_LeftDrawerOrg_LeftDrawerOrg.InterfaceLeftDrawerProps.md)

### Functions

- [default](components_LeftDrawerOrg_LeftDrawerOrg.md#default)

## Functions

### default

▸ **default**(`«destructured»`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | [`InterfaceLeftDrawerProps`](../interfaces/components_LeftDrawerOrg_LeftDrawerOrg.InterfaceLeftDrawerProps.md) |

#### Returns

`Element`

#### Defined in

[src/components/LeftDrawerOrg/LeftDrawerOrg.tsx:26](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/LeftDrawerOrg/LeftDrawerOrg.tsx#L26)
