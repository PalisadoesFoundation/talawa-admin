[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/OrganizationSidebar/OrganizationSidebar

# Module: components/UserPortal/OrganizationSidebar/OrganizationSidebar

## Table of contents

### Functions

- [default](components_UserPortal_OrganizationSidebar_OrganizationSidebar.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/components/UserPortal/OrganizationSidebar/OrganizationSidebar.tsx:18](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/UserPortal/OrganizationSidebar/OrganizationSidebar.tsx#L18)
