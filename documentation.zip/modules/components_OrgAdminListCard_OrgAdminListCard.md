[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgAdminListCard/OrgAdminListCard

# Module: components/OrgAdminListCard/OrgAdminListCard

## Table of contents

### Functions

- [default](components_OrgAdminListCard_OrgAdminListCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceOrgPeopleListCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/OrgAdminListCard/OrgAdminListCard.tsx:26](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrgAdminListCard/OrgAdminListCard.tsx#L26)
