[talawa-admin](../README.md) / [Modules](../modules.md) / screens/ForgotPassword/ForgotPassword

# Module: screens/ForgotPassword/ForgotPassword

## Table of contents

### Functions

- [default](screens_ForgotPassword_ForgotPassword.md#default)

## Functions

### default

▸ **default**(): `Element`

#### Returns

`Element`

#### Defined in

[src/screens/ForgotPassword/ForgotPassword.tsx:21](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/ForgotPassword/ForgotPassword.tsx#L21)
