[talawa-admin](../README.md) / [Modules](../modules.md) / components/UserPortal/OrganizationCard/OrganizationCard.test

# Module: components/UserPortal/OrganizationCard/OrganizationCard.test
