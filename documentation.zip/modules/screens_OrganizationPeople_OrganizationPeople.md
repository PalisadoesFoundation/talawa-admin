[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrganizationPeople/OrganizationPeople

# Module: screens/OrganizationPeople/OrganizationPeople

## Table of contents

### Functions

- [default](screens_OrganizationPeople_OrganizationPeople.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/OrganizationPeople/OrganizationPeople.tsx:28](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/OrganizationPeople/OrganizationPeople.tsx#L28)
