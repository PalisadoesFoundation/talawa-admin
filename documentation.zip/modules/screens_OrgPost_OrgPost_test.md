[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrgPost/OrgPost.test

# Module: screens/OrgPost/OrgPost.test
