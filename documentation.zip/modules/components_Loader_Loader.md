[talawa-admin](../README.md) / [Modules](../modules.md) / components/Loader/Loader

# Module: components/Loader/Loader

## Table of contents

### Functions

- [default](components_Loader_Loader.md#default)

## Functions

### default

▸ **default**(`props`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceLoaderProps` |

#### Returns

`Element`

#### Defined in

[src/components/Loader/Loader.tsx:10](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/Loader/Loader.tsx#L10)
