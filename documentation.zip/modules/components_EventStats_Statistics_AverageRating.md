[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventStats/Statistics/AverageRating

# Module: components/EventStats/Statistics/AverageRating

## Table of contents

### Functions

- [AverageRating](components_EventStats_Statistics_AverageRating.md#averagerating)

## Functions

### AverageRating

▸ **AverageRating**(`«destructured»`): `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `«destructured»` | `ModalPropType` |

#### Returns

`Element`

#### Defined in

[src/components/EventStats/Statistics/AverageRating.tsx:35](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/EventStats/Statistics/AverageRating.tsx#L35)
