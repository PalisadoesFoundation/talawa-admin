[talawa-admin](../README.md) / [Modules](../modules.md) / screens/OrgContribution/OrgContribution

# Module: screens/OrgContribution/OrgContribution

## Table of contents

### Functions

- [default](screens_OrgContribution_OrgContribution.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/screens/OrgContribution/OrgContribution.tsx:11](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/OrgContribution/OrgContribution.tsx#L11)
