[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgDelete/OrgDelete.test

# Module: components/OrgDelete/OrgDelete.test
