[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventStats/EventStatsWrapper.test

# Module: components/EventStats/EventStatsWrapper.test
