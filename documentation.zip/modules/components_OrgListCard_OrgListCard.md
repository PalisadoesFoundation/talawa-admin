[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrgListCard/OrgListCard

# Module: components/OrgListCard/OrgListCard

## Table of contents

### Interfaces

- [InterfaceOrgListCardProps](../interfaces/components_OrgListCard_OrgListCard.InterfaceOrgListCardProps.md)

### Functions

- [default](components_OrgListCard_OrgListCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | [`InterfaceOrgListCardProps`](../interfaces/components_OrgListCard_OrgListCard.InterfaceOrgListCardProps.md) |

#### Returns

`JSX.Element`

#### Defined in

[src/components/OrgListCard/OrgListCard.tsx:17](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrgListCard/OrgListCard.tsx#L17)
