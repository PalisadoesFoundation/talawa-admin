[talawa-admin](../README.md) / [Modules](../modules.md) / components/Advertisements/Advertisements

# Module: components/Advertisements/Advertisements

## Table of contents

### Functions

- [default](components_Advertisements_Advertisements.md#default)

## Functions

### default

▸ **default**(): `JSX.Element`

#### Returns

`JSX.Element`

#### Defined in

[src/components/Advertisements/Advertisements.tsx:18](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/Advertisements/Advertisements.tsx#L18)
