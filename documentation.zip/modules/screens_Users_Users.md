[talawa-admin](../README.md) / [Modules](../modules.md) / screens/Users/Users

# Module: screens/Users/Users

## Table of contents

### Functions

- [default](screens_Users_Users.md#default)

## Functions

### default

▸ **default**(): `Element`

#### Returns

`Element`

#### Defined in

[src/screens/Users/Users.tsx:23](https://github.com/palisadoes/talawa-admin/blob/5828937/src/screens/Users/Users.tsx#L23)
