[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrganizationDashCards/CardItemLoading

# Module: components/OrganizationDashCards/CardItemLoading

## Table of contents

### Functions

- [default](components_OrganizationDashCards_CardItemLoading.md#default)

## Functions

### default

▸ **default**(): `Element`

#### Returns

`Element`

#### Defined in

[src/components/OrganizationDashCards/CardItemLoading.tsx:4](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrganizationDashCards/CardItemLoading.tsx#L4)
