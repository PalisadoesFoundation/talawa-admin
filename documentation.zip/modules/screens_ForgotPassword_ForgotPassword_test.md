[talawa-admin](../README.md) / [Modules](../modules.md) / screens/ForgotPassword/ForgotPassword.test

# Module: screens/ForgotPassword/ForgotPassword.test
