[talawa-admin](../README.md) / [Modules](../modules.md) / components/OrganizationDashCards/DashboardCardLoading

# Module: components/OrganizationDashCards/DashboardCardLoading

## Table of contents

### Functions

- [default](components_OrganizationDashCards_DashboardCardLoading.md#default)

## Functions

### default

▸ **default**(): `Element`

#### Returns

`Element`

#### Defined in

[src/components/OrganizationDashCards/DashboardCardLoading.tsx:6](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/OrganizationDashCards/DashboardCardLoading.tsx#L6)
