[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventStats/EventStats.test

# Module: components/EventStats/EventStats.test
