[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventRegistrantsModal/EventRegistrantsWrapper.test

# Module: components/EventRegistrantsModal/EventRegistrantsWrapper.test
