[talawa-admin](../README.md) / [Modules](../modules.md) / components/EventListCard/EventListCard

# Module: components/EventListCard/EventListCard

## Table of contents

### Functions

- [default](components_EventListCard_EventListCard.md#default)

## Functions

### default

▸ **default**(`props`): `JSX.Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `props` | `InterfaceEventListCardProps` |

#### Returns

`JSX.Element`

#### Defined in

[src/components/EventListCard/EventListCard.tsx:32](https://github.com/palisadoes/talawa-admin/blob/5828937/src/components/EventListCard/EventListCard.tsx#L32)
